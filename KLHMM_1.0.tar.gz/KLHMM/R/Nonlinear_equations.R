#' A set of nonlinear equations corresponding to optimisation problem for transition
#' matrix probabilities
#' 
#' Takes in Kullback-Liebler distance, user predefined segment length and transition matrix probabilities
#' @param kl A matrix containing pairwise Kullback-Liebler distance computed between emission distributions
#' @param L A segment length; user specified an (expected) minimal segment length for filtering out undesirable segments
#' @param lam A matrix containing  transition probabilities
#' @return A vector corresponding to equations evaluated at transition matrix values
#' @export
#' 
Equations <- function(kl, L, lam){
  S <- nrow(lam)
  Z <- rowLogSumExps(-lam) # using log sum exp trick
  f <- rep(0, S*S)
  for (k in 1:S){
    for (j in 1:S){
      f[(k-1)*S+j] <- L * kl[k,j] - ( (L-1)*lam[k,k] + lam[j,k] + lam[k,j] + L*Z[k] - (L+1)*lam[j,j] - L*Z[j]  )
    }
  }
  return(f)
}