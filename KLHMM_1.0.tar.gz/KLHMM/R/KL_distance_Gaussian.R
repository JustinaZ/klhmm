#' Kullback-Liebler divergence between two univariate Gaussian emission densities
#' 
#' Takes in Gaussian density parameters: means and standard deviations
#' @param m A vector containing numeric values for means
#' @param s A vector containing numeric values for standard deviations
#' @return The Kullback-Liebler distance between two univariate Gaussian densities
#' @export
KL <- function(m,s){
  log(s[2]/s[1]) + (s[1]^2 + (m[1]-m[2])^2)/(2*s[2]^2) -1/2
}