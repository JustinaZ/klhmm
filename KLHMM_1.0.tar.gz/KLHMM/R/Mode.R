#' Mode
#' 
#' Takes in a vector containing numeric values
#' @param x A vector containing numeric values
#' @return Returns the mode, the most frequent value in a dataset/vector
#' @export
Mode <- function(x) {
  tmp <- unique(x)
  tmp[which.max(tabulate(match(x, tmp)))]
}
