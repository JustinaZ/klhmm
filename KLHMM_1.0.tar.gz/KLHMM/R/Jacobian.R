#' Function that computes the Jacobian matrix for a set of nonlinear equations
#' 
#' Takes in user predefined segment length and transition matrix probabilieties
#' @param L A segment length; user specified an (expected) minimal segment length for filtering out undesirable segments.
#' @param lam A matrix containing  transition probabilities
#' @return Returns the Jacobian matrix
#' @export
#' 
Jac <- function(lam, L) {
  S <- nrow(lam)
  J <- matrix(0, S*S, S*S)
  Z <- exp( rowLogSumExps(-lam) )
  
  for ( k in 1:S ) {
    for ( j in 1:S ) {
      for ( kdash in 1:S ) {
        for ( jdash in 1:S ){
          
          tmp <- 0
          
          if ( ( kdash == j ) & ( jdash == j ) & (kdash!=k)) {
            tmp <- tmp + (L+1) + (L/Z[jdash])*(-exp(-lam[kdash, jdash]))
          }
          
          if ( ( kdash == k ) & ( jdash == k ) & (jdash!=j) ) {
            tmp <- tmp - (L-1) - (L/Z[jdash])*(-exp(-lam[kdash, jdash]))
          }
          
          if ( ( kdash == j ) & ( jdash == k )  & (kdash!=k) ) {
            tmp <- tmp - 1 + (L/Z[kdash])*(-exp(-lam[kdash, jdash]))
          }
          
          if ( ( kdash == k ) & ( jdash == j ) & (kdash!=j)) {
            tmp <- tmp - 1 - (L/Z[kdash])*(-exp(-lam[kdash, jdash]))
          }
          
          J[ (k-1)*S+j, (kdash-1)*S+jdash ] <- tmp
          
        }
      }
    }
  }
  
  return(J)
}

