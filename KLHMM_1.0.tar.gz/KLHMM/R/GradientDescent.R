#' Gradient descent
#' 
#' Takes in  a Kullback-Liebler distance matrix, user predefined segment length, initial values for transition matrix, and predefined threshold
#' @param kl A matrix containing pairwise Kullback-Liebler distance computed between emission distributions
#' @param L A segment length; user specified an (expected) minimal segment length for filtering out undesirable segments
#' @param strt A matrix, initial starting value for transition matrix
#' @param epsilon A numeric value, user predefined threshold; stopping criterion
#' @param   plt logical variable; set it to TRUE for showing diagnostic plots, else set it to FALSE
#' @param alpha A numeric value, gradient descent learning rate
#' @return  Output is a matrix
 
#' @export
GD <- function(kl, L, strt, epsilon, alpha, plt){
  x0 <- strt
  LR <- c()
  J_lambda <- c()
  repeat{
    F <- Equations(kl, L, x0)
    J <- Jac(x0, L)
    
    x1 <- x0 - alpha * matrix( c( (J)%*%F ), ncol=ncol(kl))
    J_lambda  <- c(J_lambda , c( 0.5*t(F)%*%F ))
    
    F1 <- Equations(kl, L, x1)
    J1 <- Jac(x1, L)
    
    if (abs(sum(F1^2)-sum(F^2))<=epsilon){
      break
    }
    if (all(sum(F1^2)<sum(F^2))==FALSE){
      alpha <- alpha/2
    }
    x0 <- x1
    LR <- c(LR, alpha)
  }
  if (plt == 'TRUE'){
    par(mfrow = c(2, 1), mar=c(5.1,5.1,4.1,1.1))
    plot(J_lambda, type="l", lwd=2, col= "grey50", cex=1.7, xlab="iterations", ylab=expression(J(Lambda)),  cex.lab=1.3, cex.axis=1.3, font.lab=1.6, bty='n')
    plot(LR, type="l",lwd=2, col= "grey50", cex=1.7, xlab="iterations", ylab=expression(alpha),  cex.lab=1.3, cex.axis=1.3, font.lab=1.6, bty='n')
    return(x1)
  }else if (plt == 'FALSE'){
    return(x1)
  }else{
    stop("incorrect plt value") 
  }
}
