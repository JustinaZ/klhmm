#' Estimation of Kullback-Liebler divergence between two Poisson emission densities
#' 
#' Takes in Poisson density parameters
#' @param vec A vector of non-negative means
#' @param s A number of Monte carlo samples
#' @return Returns Monte Carlo estimate for Kullback-Liebler distance between two Poisson densities
#' @export
KLMC <- function(vec, s){
  x1 <- rpois(s, vec[1])
  p <- dpois(x1, vec[1], log = TRUE)
  q <- dpois(x1, vec[2], log = TRUE)
  out <- 1/s * sum(p - q)
  out
}