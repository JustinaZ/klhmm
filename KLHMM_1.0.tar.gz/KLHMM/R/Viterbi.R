#' Viterbi algorithm
#' 
#' Takes in data, estimated transition matrix probabilities, initial transition probabilities, and density information
#' @param llk A matrix containing data evaluated at log-likelihood 
#' @param Pil A matrix with log-transition probabilities
#' @param delta A vector containing initial transition probabilities
#' @return  Returns estimated hidden sequence
#' @export
# Pil - is log(Pi)
viterbi <- function (llk, Pil, delta){
    n <- nrow(llk)
    m <- nrow(Pil)
    nu <- matrix(NA, nrow = n, ncol = m)
    y <- rep(NA, n)
    nu[1, ] <- log(delta) + llk[1,] 
    logPi <- Pil 
    for (i in 2:n) {
      matrixnu <- matrix(nu[i - 1, ], nrow = m, ncol = m)
      nu[i, ] <- apply(matrixnu + logPi, 2, max) + llk[i,]
    }
    y[n] <- which.max(nu[n, ])
    for (i in seq(n - 1, 1, -1)) {
      y[i] <- which.max(logPi[, y[i + 1]] + nu[i, ])
    }
    return(y)
}
