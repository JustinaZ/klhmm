#' Function to compute Log-Sum-Exp trick
#' 
#' Takes in matrix and computes Log-Sum-Exp across matrix rows
#' @param x A matrix containing numeric values
#' @return Output is a vector 
#' @export
rowLogSumExps <- function(x){
  apply(x, 1, function(y) (max(y) + log(sum(exp(y - max(y)))) ) )
}